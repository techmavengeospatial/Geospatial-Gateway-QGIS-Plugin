# Geospatial-Gateway-QGIS-Plugin
This plugin requires the purchase of either Windows Tile Server https://tileserver.techmaven.net or Ready to Go Cloud or On-Prem/Edge Virtual Machine Solution https://geospatialcloudserv.com 
